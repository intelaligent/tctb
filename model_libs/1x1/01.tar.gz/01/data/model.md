---
model_id: "model_libs-1x1-01"
dimensions: "1x1"
group: "model_libs"
subgroup: "1x1"
number: "01"
model_name: "model"
---
