---
model_id: "model_libs-1x1-02"
dimensions: "1x1"
group: "model_libs"
subgroup: "1x1"
number: "02"
model_name: "model"
---
