---
model_id: "model_libs-1x1-04"
dimensions: "1x1"
group: "model_libs"
subgroup: "1x1"
number: "04"
model_name: "model"
---
