---
model_id: "model_libs-2x1-07"
dimensions: "2x1"
group: "model_libs"
subgroup: "2x1"
number: "07"
model_name: "model"
---
