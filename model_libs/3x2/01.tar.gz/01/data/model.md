---
model_id: "model_libs-3x2-01"
dimensions: "3x2"
group: "model_libs"
subgroup: "3x2"
number: "01"
model_name: "model"
---
