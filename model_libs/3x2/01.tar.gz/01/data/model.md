---
model_id: "3x2--01"
dimensions: "3x2"
group: "3x2"
subgroup: ""
number: "01"
model_name: "model"
---
