---
model_id: "model_libs-3x2-02"
dimensions: "3x2"
group: "model_libs"
subgroup: "3x2"
number: "02"
model_name: "model"
---
