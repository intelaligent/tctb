---
model_id: "3x2--02"
dimensions: "3x2"
group: "3x2"
subgroup: ""
number: "02"
model_name: "model"
---
