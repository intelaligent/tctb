---
model_id: "model_libs-3x2-03"
dimensions: "3x2"
group: "model_libs"
subgroup: "3x2"
number: "03"
model_name: "model"
---
