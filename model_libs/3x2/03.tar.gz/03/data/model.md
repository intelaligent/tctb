---
model_id: "3x2--03"
dimensions: "3x2"
group: "3x2"
subgroup: ""
number: "03"
model_name: "model"
---
