---
model_id: "model_libs-5x3-01"
dimensions: "5x3"
group: "model_libs"
subgroup: "5x3"
number: "01"
model_name: "model"
---
