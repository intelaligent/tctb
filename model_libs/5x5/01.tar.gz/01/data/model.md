---
model_id: "model_libs-5x5-01"
dimensions: "5x5"
group: "model_libs"
subgroup: "5x5"
number: "01"
model_name: "model"
---
